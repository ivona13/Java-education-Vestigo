package hr.vestigo.java.education.hw4.plants.trees;

import hr.vestigo.java.education.hw4.plants.Tree;

/**
 * This class represents special type of tree, beech.
 * 
 * @author ivona
 *
 */
public class Beech extends Tree {

	/**
	 * type of tree
	 */
	private static final String treeType = "beech";

	/**
	 * Constructor
	 */
	public Beech() {
		super(treeType);
	}
}

package hr.vestigo.java.education.hw4.plants;

/**
 * This class is used to represent tree in the garden. <br/>
 * Tree is the sort of plant that our garden can contain.
 * 
 * @author ivona
 *
 */
public abstract class Tree implements Plantable {

	/**
	 * number of watering that tree needs to grown up
	 * 
	 */
	private static final int NEEDED_NUMBER_OF_WATERING = 2;

	/**
	 * type of tree
	 */
	String treeType;

	/**
	 * number of tree watering
	 */
	int numberOfWatering = 0;

	/**
	 * Constructor
	 * 
	 * @param treeType type of tree
	 */
	public Tree(String treeType) {
		this.treeType = treeType;
	}

	@Override
	public void addWater() {
		numberOfWatering++;
	}

	@Override
	public String toString() {
		if (numberOfWatering >= NEEDED_NUMBER_OF_WATERING) {
			return treeType.toUpperCase();
		}
		return treeType.toLowerCase();
	}
}

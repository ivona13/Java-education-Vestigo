package hr.vestigo.java.education.hw4.plants.trees;

import hr.vestigo.java.education.hw4.plants.Tree;

/**
 * This class represents special type of tree, oak.
 * 
 * @author ivona
 *
 */
public class Oak extends Tree {

	/**
	 * type of tree
	 */
	private static final String treeType = "oak";

	/**
	 * Constructor
	 */
	public Oak() {
		super(treeType);
	}
}

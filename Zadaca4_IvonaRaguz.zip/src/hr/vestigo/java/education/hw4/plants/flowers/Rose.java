package hr.vestigo.java.education.hw4.plants.flowers;

import hr.vestigo.java.education.hw4.plants.Flower;

/**
 * This class represents special type of flower, rose.
 * 
 * @author ivona
 *
 */
public class Rose extends Flower {

	/**
	 * type of flower
	 */
	private final static String flowerType = "rose";

	/**
	 * Constructor
	 */
	public Rose() {
		super(flowerType);
	}
}

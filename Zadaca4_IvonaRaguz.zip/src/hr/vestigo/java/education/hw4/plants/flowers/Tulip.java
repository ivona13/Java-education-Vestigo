package hr.vestigo.java.education.hw4.plants.flowers;

import hr.vestigo.java.education.hw4.plants.Flower;

/**
 * This class represents special type of flower, tulip.
 * 
 * @author ivona
 *
 */
public class Tulip extends Flower {

	/**
	 * type of flower
	 */
	private final static String flowerType = "tulip";

	/**
	 * Constructor
	 */
	public Tulip() {
		super(flowerType);
	}

}

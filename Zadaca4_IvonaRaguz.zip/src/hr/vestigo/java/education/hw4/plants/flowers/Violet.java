package hr.vestigo.java.education.hw4.plants.flowers;

import hr.vestigo.java.education.hw4.plants.Flower;

/**
 * This class represents special type of flower, violet.
 * 
 * @author ivona
 *
 */
public class Violet extends Flower {

	/**
	 * type of flower
	 */
	private final static String flowerType = "violet";

	/**
	 * Constructor
	 */
	public Violet() {
		super(flowerType);
	}

}

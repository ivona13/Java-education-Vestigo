package hr.vestigo.java.education.hw4.plants.trees;

import hr.vestigo.java.education.hw4.plants.Tree;

/**
 * This class represents special type of tree, pine.
 * 
 * @author ivona
 *
 */
public class Pine extends Tree {

	/**
	 * type of tree
	 */
	private static final String treeType = "pine";

	/**
	 * Constructor
	 */
	public Pine() {
		super(treeType);
	}
}

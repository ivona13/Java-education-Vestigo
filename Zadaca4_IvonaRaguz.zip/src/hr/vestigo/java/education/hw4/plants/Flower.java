package hr.vestigo.java.education.hw4.plants;

/**
 * This class is used to represent flower in the garden. <br/>
 * Flower is a sort of plant that our garden can contain.
 * 
 * @author ivona
 *
 */
public abstract class Flower implements Plantable {

	/**
	 * number of watering that flower needs to grown up
	 */
	private static final int NEEDED_NUMBER_OF_WATERING = 1;

	/**
	 * type of flower
	 */
	String flowerType;

	/**
	 * number of flower watering
	 */
	int numberOfWatering = 0;

	/**
	 * Constructor
	 * 
	 * @param flowerType type of flower
	 */
	public Flower(String flowerType) {
		this.flowerType = flowerType;
	}

	@Override
	public void addWater() {
		numberOfWatering++;
	}

	@Override
	public String toString() {
		if (numberOfWatering >= NEEDED_NUMBER_OF_WATERING) {
			return flowerType.toUpperCase();
		}
		return flowerType.toLowerCase();
	}

}

package hr.vestigo.java.education.hw4.plants;

/**
 * This interface represents a plant in the garden.
 * 
 * @author ivona
 *
 */
public interface Plantable {

	/**
	 * This method is used to water plant in the garden.
	 */
	void addWater();
}

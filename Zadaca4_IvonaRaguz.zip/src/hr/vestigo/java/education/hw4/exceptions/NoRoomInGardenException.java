package hr.vestigo.java.education.hw4.exceptions;

/**
 * This type of exception is thrown if there no enough appropriate space on plot
 * for planting.
 * 
 * @author ivona
 *
 */
public class NoRoomInGardenException extends Exception {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "There is not enough appropriate space on plot for planting.";
	}
}

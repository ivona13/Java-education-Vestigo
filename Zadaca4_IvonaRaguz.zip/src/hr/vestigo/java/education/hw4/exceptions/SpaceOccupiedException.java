package hr.vestigo.java.education.hw4.exceptions;

/**
 * This exception is thrown if there is already a plant on the place where
 * the new plant wants to be.
 * 
 * @author ivona
 *
 */
public class SpaceOccupiedException extends Exception {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "There is already another plant on the place.";
	}
}

package hr.vestigo.java.education.hw4.exceptions;

/**
 * This type of exception is thrown if the type of plant is not appropriate to
 * the type of plot where it is planted.
 * 
 * @author ivona
 *
 */
public class InvalidPlantType extends Exception {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Invalid type of plant on the plot.";
	}
}

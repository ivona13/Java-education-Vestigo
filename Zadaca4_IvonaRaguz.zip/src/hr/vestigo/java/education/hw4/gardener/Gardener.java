package hr.vestigo.java.education.hw4.gardener;

import hr.vestigo.java.education.hw4.exceptions.InvalidPlantType;
import hr.vestigo.java.education.hw4.exceptions.NoRoomInGardenException;
import hr.vestigo.java.education.hw4.exceptions.SpaceOccupiedException;
import hr.vestigo.java.education.hw4.garden.Garden;
import hr.vestigo.java.education.hw4.garden.Plot;
import hr.vestigo.java.education.hw4.garden.plots.Flowerbed;
import hr.vestigo.java.education.hw4.garden.plots.Orchard;
import hr.vestigo.java.education.hw4.plants.Plantable;

/**
 * This class is used to represent gardener. <br/>
 * Gardener can plant, water plants and admire plants.
 * 
 * @author ivona
 *
 */
public class Gardener {

	/**
	 * This method is used to plant an input plant in the first free location in the
	 * garden.<br/>
	 * The type of plant has to be appropriate to the garden's plants type.
	 * 
	 * @param g garden to plant in
	 * @param p plant
	 * @throws NoRoomInGardenException if there is no place in the garden
	 */
	public void plant(Garden g, Plantable p) throws NoRoomInGardenException {

		boolean planted = false;
		for (int i = 0; i < g.plots.length; i++) {
			for (int j = 0; j < Plot.CAPACITY; j++) {
				if (g.plots[i].getPlant(j) == null) {
					try {
						g.plots[i].addPlant(j, p);
						planted = true;
						System.out.println("Gardener: I've planted the " + p.toString() + ".");
						return;
					} catch (InvalidPlantType e) {
					} catch (SpaceOccupiedException e) {
					}
				}
			}
		}
		if (!planted) {
			throw new NoRoomInGardenException();
		}
	}

	/**
	 * This method is used to water once all plants in the garden.
	 * 
	 * @param g garden for watering
	 */
	public void waterPlants(Garden g) {
		for (int i = 0; i < g.plots.length; i++) {
			Plot plot = g.plots[i];
			for (int j = 0; j < plot.countPlants(); j++) {
				Plantable plant = plot.getPlant(j);
				if (plant != null) {
					plant.addWater();
				}
			}
		}
		System.out.println("Gardener: Drink my children, drink and GROW! HAHAHAHAHA!!");
	}

	/**
	 * This method is used to print out the content of garden.
	 * 
	 * @param g garden whose content will be printed
	 */
	public void admirePlants(Garden g) {
		System.out.println("The gardener admires the garden.");
		System.out.println(g.toString());
	}

	/**
	 * This method is used to prepare garden. <br/>
	 * At the beginning, plots of the garden are empty.
	 * 
	 * @param g garden to be prepared
	 */
	public void prepareGarden(Garden g) {
		g.plots[0] = new Flowerbed();
		g.plots[1] = new Orchard();
	}
}

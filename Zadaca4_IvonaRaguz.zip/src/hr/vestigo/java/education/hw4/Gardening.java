package hr.vestigo.java.education.hw4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import hr.vestigo.java.education.hw4.exceptions.NoRoomInGardenException;
import hr.vestigo.java.education.hw4.garden.Garden;
import hr.vestigo.java.education.hw4.gardener.Gardener;
import hr.vestigo.java.education.hw4.plants.Plantable;
import hr.vestigo.java.education.hw4.plants.flowers.Rose;
import hr.vestigo.java.education.hw4.plants.flowers.Tulip;
import hr.vestigo.java.education.hw4.plants.flowers.Violet;
import hr.vestigo.java.education.hw4.plants.trees.Beech;
import hr.vestigo.java.education.hw4.plants.trees.Oak;
import hr.vestigo.java.education.hw4.plants.trees.Pine;

/**
 * This class is used for demonstrating gardening. <br/>
 * User can assign different commands to the gardener who cares about garden.
 * 
 * @author ivona
 *
 */
public class Gardening {

	/**
	 * instructions for user which commands can be enter
	 */
	private static final String INSTRUCTION = "Enter command: P(lant)[Plant type] - e.g. PO to (P)lant an (O)ak | W(ater plants) "
			+ "| L(ook at garden) | Q(uit)";

	/**
	 * This method is executed after running the program.
	 * 
	 * @param args command arguments
	 * @throws IOExceptions possible exception while reading input commands
	 */
	public static void main(String[] args) throws IOException {
		Garden garden = new Garden();
		garden(garden);
	}

	/**
	 * This method is used for gardening the garden.
	 * 
	 * @param garden garden
	 * @throws IOException possible exception while reading input commands
	 */
	private static void garden(Garden garden) throws IOException {
		Gardener gardener = new Gardener();
		gardener.prepareGarden(garden);

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("The gardener has entered the garden:");
		System.out.println(garden.toString());
		System.out.println(INSTRUCTION);
		String command;
		System.out.print(">> ");
		while ((command = in.readLine()) != null && !command.equals("Q")) {
			parseCommand(command.trim(), gardener, garden);
			System.out.println(INSTRUCTION);
			System.out.print(">> ");

		}
		System.out.println("The gardener leaves the garden.");
		return;
	}

	/**
	 * This method is used for parsing command. <br/>
	 * User enters commands which have to be interpreted.
	 * 
	 * @param command  command the user enter
	 * @param gardener gardener who does actions in garden
	 * @param garden   garden
	 */
	private static void parseCommand(String command, Gardener gardener, Garden garden) {
		// commands of type PX
		if (command.startsWith("P")) {
			Plantable plant = parsePlant(command.substring(1));
			if (plant != null) {
				try {
					gardener.plant(garden, plant);
				} catch (NoRoomInGardenException e) {
					System.out.println("No appropriate place in garden for planting.");
				}
			}
			return;
		}

		switch (command) {
		case "W":
			gardener.waterPlants(garden);
			break;
		case "L":
			gardener.admirePlants(garden);
			break;
		default:
			System.out.println("Unknown command.");
			break;
		}
	}

	/**
	 * This method is used for parsing the type of plant.
	 * 
	 * @param plantType symbol of the type of a plant
	 * @return plant whose type name starts with input string
	 */
	private static Plantable parsePlant(String plantType) {
		Plantable plant = null;
		switch (plantType) {
		case "O":
			plant = new Oak();
			break;

		case "B":
			plant = new Beech();
			break;

		case "P":
			plant = new Pine();
			break;

		case "R":
			plant = new Rose();
			break;

		case "T":
			plant = new Tulip();
			break;

		case "V":
			plant = new Violet();
			break;

		default:
			System.out.println("Unknown type of plant.");
			break;
		}
		return plant;
	}
}

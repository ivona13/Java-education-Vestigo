package hr.vestigo.java.education.hw4.garden;

/**
 * This class represents whole garden which contains plots.
 * 
 * @author ivona
 *
 */
public class Garden {

	/**
	 * number of plots that garden consists of
	 */
	private static final int NUMBER_OF_PLOTS = 2;

	/**
	 * Array of plots of the garden
	 */
	public Plot[] plots = new Plot[NUMBER_OF_PLOTS];

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Garden:\n");
		for (int i = 0; i < plots.length; i++) {
			if (plots[i] != null) {
				sb.append(i + 1).append(". ").append(plots[i].toString());
				sb.append("\n");
			}
		}
		return sb.toString();
	}
}

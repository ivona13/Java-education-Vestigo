package hr.vestigo.java.education.hw4.garden;

import hr.vestigo.java.education.hw4.exceptions.InvalidPlantType;
import hr.vestigo.java.education.hw4.exceptions.SpaceOccupiedException;
import hr.vestigo.java.education.hw4.plants.Plantable;

/**
 * This interface represents plots in the garden.
 * 
 * @author ivona
 *
 */
public interface Plot {

	/**
	 * capacity of plot: number of plants a plot can contain
	 */
	public static final int CAPACITY = 5;

	/**
	 * This method is used to plant a given plant in a given place in the plot.
	 * 
	 * @param i place in a plot for planting
	 * @param p plant
	 * @return <span>true</span> if planting is successful <br/>
	 *         <span>false</span> otherwise
	 * @throws InvalidPlantType       if type of plant is not appropriate for a plot
	 * @throws SpaceOccupiedException if there is no place for planting in a plot
	 */
	boolean addPlant(int i, Plantable p) throws InvalidPlantType, SpaceOccupiedException;

	/**
	 * This method is used to get a plant that is placed on a special location on
	 * the plot.
	 * 
	 * @param i location
	 * @return <span>null<span> if there is no plant on that location<br/>
	 *         <span>plant with input location<span>, otherwise
	 */
	Plantable getPlant(int i);

	/**
	 * This method is used to get number of plants planted on this plot.
	 * 
	 * @return number of plants that a plot contain
	 */
	int countPlants();
}

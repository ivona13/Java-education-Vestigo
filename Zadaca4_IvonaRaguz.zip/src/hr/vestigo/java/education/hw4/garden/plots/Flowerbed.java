package hr.vestigo.java.education.hw4.garden.plots;

import hr.vestigo.java.education.hw4.exceptions.InvalidPlantType;
import hr.vestigo.java.education.hw4.exceptions.SpaceOccupiedException;
import hr.vestigo.java.education.hw4.garden.Plot;
import hr.vestigo.java.education.hw4.plants.Flower;
import hr.vestigo.java.education.hw4.plants.Plantable;

/**
 * This class represents special type of plot, flowerbed plot.<br/>
 * Only flowers are allowed to be planted on this kind of plot.
 * 
 * @author ivona
 *
 */
public class Flowerbed implements Plot {

	/**
	 * planted flowers
	 */
	Flower flowers[] = new Flower[CAPACITY];

	@Override
	public boolean addPlant(int i, Plantable p) throws InvalidPlantType, SpaceOccupiedException {
		if (!(p instanceof Flower)) {
			throw new InvalidPlantType();
		}

		if (flowers[i] != null) {
			throw new SpaceOccupiedException();
		}

		flowers[i] = (Flower) p;
		return true;
	}

	@Override
	public Plantable getPlant(int i) {
		if (i < 0 || i >= flowers.length) {
			throw new IndexOutOfBoundsException("Invalid place on plot.");
		}
		return flowers[i];
	}

	@Override
	public int countPlants() {
		int countFlowers = 0;
		for (Flower f : flowers) {
			if (f != null) {
				countFlowers++;
			}
		}
		return countFlowers;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Flowerbed\n\t");
		for (int i = 0; i < CAPACITY; i++) {
			sb.append(i + 1).append(". ");
			if (flowers[i] == null) {
				sb.append("*empty* | ");
			} else {
				sb.append(flowers[i].toString()).append(" | ");
			}
		}
		return sb.toString();
	}
}
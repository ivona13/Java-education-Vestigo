package hr.vestigo.java.education.hw4.garden.plots;

import hr.vestigo.java.education.hw4.exceptions.InvalidPlantType;
import hr.vestigo.java.education.hw4.exceptions.SpaceOccupiedException;
import hr.vestigo.java.education.hw4.garden.Plot;
import hr.vestigo.java.education.hw4.plants.Plantable;
import hr.vestigo.java.education.hw4.plants.Tree;

/**
 * This class represents special type of plot, orchard plot.<br/>
 * Only trees are allowed to be planted on this kind of plot.
 * 
 * @author ivona
 *
 */
public class Orchard implements Plot {

	/**
	 * planted trees
	 */
	Tree[] trees = new Tree[CAPACITY];

	@Override
	public boolean addPlant(int i, Plantable p) throws InvalidPlantType, SpaceOccupiedException {
		if (!(p instanceof Tree)) {
			throw new InvalidPlantType();
		}

		if (trees[i] != null) {
			throw new SpaceOccupiedException();
		}

		trees[i] = (Tree) p;
		return true;
	}

	@Override
	public Plantable getPlant(int i) {
		if (i < 0 || i >= trees.length) {
			throw new IndexOutOfBoundsException("Invalid place on plot.");
		}
		return trees[i];
	}

	@Override
	public int countPlants() {
		int countTrees = 0;
		for (Tree t : trees) {
			if (t != null) {
				countTrees++;
			}
		}
		return countTrees;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Orchard\n\t");
		for (int i = 0; i < CAPACITY; i++) {
			sb.append(i + 1).append(". ");
			if (trees[i] == null) {
				sb.append("*empty* | ");
			} else {
				sb.append(trees[i].toString()).append(" | ");
			}
		}
		return sb.toString();
	}
}
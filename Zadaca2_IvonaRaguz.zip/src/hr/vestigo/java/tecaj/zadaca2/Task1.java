package hr.vestigo.java.tecaj.zadaca2;

import java.util.Arrays;
import java.util.Collections;

/**
 * This class is used to demonstrate descending sort of array. </br>
 * The array to be sorted is obtained by concatenation of three arrays.
 * 
 * @author ivona
 *
 */
public class Task1 {

	/**
	 * Method which is called upon program execution.
	 * 
	 * @param args Command line input arguments
	 */
	public static void main(String[] args) {

		Integer[] array1 = { 9, 8, 937, 912, 1961, 24, 7 };
		Integer[] array2 = { 61, 7285, 17, 826, 175, 6813, 8123 };
		Integer[] array3 = { 4373, 3, 92, 99, 897, 32, 50, 1, 67 };

		Integer[] concatenatedArray = concateArrays(array1, array2, array3);
		Arrays.sort(concatenatedArray, Collections.reverseOrder());
		printArray(concatenatedArray);
	}

	/**
	 * This method is used for concatenating arrays.
	 * 
	 * @param array1 first input array
	 * @param array2 second input array
	 * @param array3 third input array
	 * @return array obtained by concatenating three input arrays
	 */
	private static Integer[] concateArrays(Integer[] array1, Integer[] array2, Integer[] array3) {
		int length1 = array1.length;
		int length2 = array2.length;
		int length3 = array3.length;

		Integer[] concatenatedArray = new Integer[length1 + length2 + length3];

		for (int i = 0; i < concatenatedArray.length; i++) {
			if (i < length1) {
				concatenatedArray[i] = array1[i];
			} else if (i >= length1 && i < (length1 + length2)) {
				concatenatedArray[i] = array2[i - length1];
			} else {
				concatenatedArray[i] = array3[i - length1 - length2];
			}
		}
		return concatenatedArray;
	}

	/**
	 * This method is used for printing array.
	 * 
	 * @param array input array to be printed
	 */
	private static void printArray(Integer[] array) {
		System.out.print("{ ");
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i]);
			if (i != array.length - 1) {
				System.out.print(", ");
			}
		}
		System.out.print(" }");
	}
}

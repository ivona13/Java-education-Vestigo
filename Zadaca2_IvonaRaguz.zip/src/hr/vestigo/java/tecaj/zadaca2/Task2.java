package hr.vestigo.java.tecaj.zadaca2;

/**
 * This class is used to demonstrate finding number of appearances two strings
 * side by side.</br>
 * Two strings we are searching the appearance of are 'Tom' and 'Jerry'.
 * 
 * @author ivona
 *
 */
public class Task2 {

	/**
	 * Method which is called upon program execution.
	 * 
	 * @param args Command line input arguments
	 */
	public static void main(String[] args) {
		String[] array1 = { "Nick", "Tom", "Jerry", "Bob", "Jerry", "Mike", "Tom", "Jerry", "Tom" };
		String[] array2 = { "Hello", "World", "Java", "Jerry", "Bob", "Tom", "Jerry" };
		String[] array3 = { "Rob", "Mike", "George", "Jerry", "Tom", "David", "John", "Jack", "Tom" };

		int counter1 = findNumberOfApperancesSideBySide(array1, "Tom", "Jerry");
		int counter2 = findNumberOfApperancesSideBySide(array2, "Tom", "Jerry");
		int counter3 = findNumberOfApperancesSideBySide(array3, "Tom", "Jerry");

		System.out.println("Stringovi Tom i Jerry se u prvom polju jedan pored drugog nalaze " + counter1 + " puta.");
		System.out.println("Stringovi Tom i Jerry se u drugom polju jedan pored drugog nalaze " + counter2 + " puta.");
		System.out.println("Stringovi Tom i Jerry se u trećem polju jedan pored drugog nalaze " + counter3 + " puta.");
		System.out.println("Ukupno pojavljivanja stringova Tom i Jerry jedan pored drugog u svim poljima: "
				+ (counter1 + counter2 + counter3) + " puta");

	}

	/**
	 * This method is used for finding number of appearances side by side of two
	 * input strings in given array.
	 * 
	 * @param array   array to search appearances into
	 * @param string1 first string
	 * @param string2 second string
	 * @return number of appearances
	 */
	private static int findNumberOfApperancesSideBySide(String[] array, String string1, String string2) {

		int counter = 0;
		for (int i = 0; i < array.length - 1; i++) {
			if ((array[i].equals(string1) && array[i + 1].equals(string2))
					|| (array[i].equals(string2) && array[i + 1].equals(string1))) {
				counter++;
			}
		}
		return counter;
	}
}

package hr.vestigo.java.tecaj.zadaca2;

import java.util.Arrays;

/**
 * This class is used for demonstrating sort of odd elements of 2-dimensional
 * array. </br>
 * We consider element of multidimensional array to be odd if its index in the
 * array is an odd integer.
 * 
 * @author ivona
 *
 */
public class Task4 {

	/**
	 * Method which is called upon program execution.
	 * 
	 * @param args Command line input arguments
	 */
	public static void main(String[] args) {
		char[][] charMatrix = { { 'K', 'R', 'Q', '9', 'S' }, { 'D', 'A', 'S', 'T', 'A', 'L' }, { 'A', 'F', 'C', 'V' },
				{ 'O', 'B', 'A', 'W', '2' }, { 'Y', 'Z', 'E', 'S' } };

		sortOddElements(charMatrix);
		printMatrix(charMatrix);
	}

	/**
	 * This method is used for sorting odd elements of 2-dimensional array.
	 * 
	 * @param charMatrix 2-dimensional array whose odd elements will be sorted
	 */
	private static void sortOddElements(char[][] charMatrix) {
		for (int i = 0; i < charMatrix.length; i++) {
			if (i % 2 == 1) {
				Arrays.sort(charMatrix[i]);
			}
		}
	}

	/**
	 * This method is used for printing 2-dimensional array.
	 * 
	 * @param charMatrix 2-dimensional array to be printed
	 */
	private static void printMatrix(char[][] charMatrix) {
		System.out.print("{");
		for (int i = 0; i < charMatrix.length; i++) {
			System.out.print("{ ");
			for (int j = 0; j < charMatrix[i].length; j++) {
				System.out.print(charMatrix[i][j]);
				if (j != charMatrix[i].length - 1) {
					System.out.print(", ");
				}
			}
			System.out.print(" }");
			if (i != charMatrix.length - 1) {
				System.out.print(", ");
			}
		}
		System.out.print("}");
	}
}

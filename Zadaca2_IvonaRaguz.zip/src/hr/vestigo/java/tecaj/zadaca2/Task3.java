package hr.vestigo.java.tecaj.zadaca2;

/**
 * This class is used for demonstrating segregation of palindromes from array.
 * </br>
 * String is considered to be palindrom if it is read the same backward as
 * forward, ignoring spaces and case of letters.</br>
 * Palindromes are saved to another array.</br>
 * If the palindrome has even number of letters, it is saved in upper case;
 * otherwise it is saved originally.
 * 
 * @author ivona
 *
 */
public class Task3 {

	/**
	 * Size of arrays
	 */
	static final int SIZE_OF_ARRAYS = 16;

	/**
	 * Method which is called upon program execution.
	 * 
	 * @param args Command line input arguments
	 */
	public static void main(String[] args) {
		String[] array = { "Bob", "civic", "Time", "rAdar", "lol", "DotA", "dEtarTrated", "sAiPpuaKivikauPPias",
				"rotoR", "solo", "kite", "Rick", "Evee", "discipline", "_wow_", "sTat" };

		String[] palindroms = new String[SIZE_OF_ARRAYS];

		fillArrayWithPalindromes(palindroms, array);
		printArray(palindroms);
	}

	/**
	 * This method is used for checking if string is a palindrome, ignoring spaces
	 * and letter cases.
	 * 
	 * @param string string to be checked
	 * @return true, if string is palindrome </br>
	 *         false otherwise
	 */
	private static boolean checkIfPalindrome(String string) {
		boolean isPalindrom = true;
		// ignore all blanks
		string = string.replaceAll("\\s+", "");

		for (int i = 0; i < string.length() / 2; i++) {
			if (string.toLowerCase().charAt(i) != string.toLowerCase().charAt(string.length() - 1 - i)) {
				isPalindrom = false;
				break;
			}
		}
		return isPalindrom;
	}

	/**
	 * This method is used for filling array with palindromes from another array.
	 * 
	 * @param palindroms array to be filled with palindromes
	 * @param array      array to search palindromes into
	 */
	private static void fillArrayWithPalindromes(String[] palindroms, String[] array) {
		int numberOfElements = 0;

		for (int i = 0; i < array.length; i++) {
			if (checkIfPalindrome(array[i])) {
				if (array[i].length() % 2 == 0) {
					palindroms[numberOfElements] = array[i].toUpperCase();
				} else {
					palindroms[numberOfElements] = array[i];
				}
				numberOfElements++;
			}
		}
	}

	/**
	 * This method is used for printing array.
	 * 
	 * @param array array to be printed
	 */
	private static void printArray(String[] array) {
		System.out.print("{ ");
		for (int i = 0; i < array.length; i++) {
			if (array[i] == null) {
				break;
			}
			System.out.print(array[i]);
			if (i != array.length - 1) {
				System.out.print(", ");
			}
		}
		System.out.print(" }");
	}
}
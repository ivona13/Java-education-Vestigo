package hr.vestigo.java.tecaj.zadaca1;

import java.util.Scanner;

/**
 * Class which calculates the sum of digits of a five digit number.<br/>
 * The number is entered through the command line.
 * 
 * @author ivona
 *
 */
public class Zadatak3 {

	/**
	 * Method which is called upon program execution.
	 * 
	 * @param args Command line input arguments
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Please enter a five digit number: ");
		int number = sc.nextInt();
		int sum = 0;

		while (number > 0) {
			sum += (number % 10);
			number /= 10;
		}

		System.out.println("Sum of digits is: " + sum);
		sc.close();
	}
}

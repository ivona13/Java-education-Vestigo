package hr.vestigo.java.tecaj.zadaca1;

import java.util.Scanner;

/**
 * Class for checking if a year is leap. <br/>
 * The year is entered through the command line.
 * 
 * @author ivona
 *
 */
public class Zadatak1 {

	/**
	 * Method which is called upon program execution.
	 * 
	 * @param args Command line input arguments
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter a year:");
		int year = sc.nextInt();

		String answer = "Given year is leap: " + ((year % 4 > 0) ? "False" : "True");
		System.out.println(answer);
		sc.close();
	}
}

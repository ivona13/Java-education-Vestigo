package hr.vestigo.java.tecaj.zadaca1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Class for checking if a store is open on particular time.<br/>
 * The store is open 8-16 every day, Monday - Friday. <br/>
 * The hour and the day of the week for checking are entered through the command
 * line.
 * 
 * @author ivona
 *
 */
public class Zadatak5 {

	/**
	 * Method which is called upon program execution.
	 * 
	 * @param args Command line input arguments
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter an hour:");
		int hour = sc.nextInt();
		System.out.println("Please enter a day:");
		String day = sc.next();

		System.out.println("On given day and time store is open: " + checkIfStoreIsOpen(hour, day));
		sc.close();
	}

	/**
	 * Method which checks if the store is open at particular hour on particular day.<br/>
	 * The store is open 08-16 every day between and including Monday through Friday.
	 * 
	 * @param hour hour to check if store is open at
	 * @param day  day to check if store is open on
	 * @return <span><b>True</b></span> if store is open <br/>
	 * 		   <span><b>False</b></span> otherwise
	 */
	private static String checkIfStoreIsOpen(int hour, String day) {
		List<String> workingDays = new ArrayList<String>();
		initializeList(workingDays);

		String answer = (workingDays.contains(day.toLowerCase()) 
						&& hour >= 8 && hour <= 16) ? "True" : "False";
		return answer;
	}

	/**
	 * Method for filling the list with working days of the week.<br/>
	 * Working days of the week are Monday - Friday.<br/>
	 * 
	 * @param workindDays List to be filled with working day of store
	 */
	private static void initializeList(List<String> workindDays) {
		workindDays.add("monday");
		workindDays.add("tuesday");
		workindDays.add("wednesday");
		workindDays.add("thursday");
		workindDays.add("friday");
	}
}

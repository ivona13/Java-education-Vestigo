package hr.vestigo.java.tecaj.zadaca1;

import java.util.Scanner;

/**
 * Class which calculates distance between two points. <br/>
 * Coordinates of points are entered through the command line.
 * 
 * @author ivona
 *
 */
public class Zadatak4 {

	/**
	 * Method which is called upon program execution.
	 * 
	 * @param args Command line input arguments
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter x coordinate of first number:");
		int x1 = sc.nextInt();
		System.out.println("Enter y coordinate of first number:");
		int y1 = sc.nextInt();
		System.out.println("Enter x coordinate of second number:");
		int x2 = sc.nextInt();
		System.out.println("Enter x coordinate of second number:");
		int y2 = sc.nextInt();

		double distance = Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
		
		System.out.println("Distance between two points is: " + distance);
		sc.close();
	}

}

package hr.vestigo.java.tecaj.zadaca1;

import java.util.Scanner;

/**
 * Class which calculates a potency of a number. <br/>
 * The base and the potency are entered through the command line.
 * 
 * @author ivona
 *
 */
public class Zadatak2 {

	/**
	 * Method which is called upon program execution.
	 * 
	 * @param args Command line input arguments
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter a number:");
		int number = sc.nextInt();
		System.out.println("Please enter a potency:");
		int potency = sc.nextInt();

		int result = (int) Math.pow(number, potency);
		
		System.out.println(potency + ". potency of a given number is: " + result);
		sc.close();
	}

}

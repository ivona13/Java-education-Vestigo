package hr.vestigo.java.education.hw5.parking.vehicle;

/**
 * This class represents possible different size of vehicle.
 * 
 * @author ivona
 *
 */
public enum VehicleSize {
	/**
	 * Small size of vehicle
	 */
	SMALL,

	/**
	 * Medium size of vehicle
	 */
	MEDIUM,

	/**
	 * Large size of vehicle
	 */
	LARGE

}

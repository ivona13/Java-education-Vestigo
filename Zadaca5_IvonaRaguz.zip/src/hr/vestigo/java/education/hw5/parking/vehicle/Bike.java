package hr.vestigo.java.education.hw5.parking.vehicle;

/**
 * This class is used to represent bike.
 * 
 * @author ivona
 *
 */
public class Bike implements Vehicle {

	/**
	 * Type of bike - regular or handicapped
	 */
	VehicleType bikeType;

	/**
	 * Constructor
	 * 
	 * @param bikeType bike type
	 */
	public Bike(VehicleType bikeType) {
		this.bikeType = bikeType;
	}

	@Override
	public VehicleSize getSize() {
		return VehicleSize.SMALL;
	}

	@Override
	public VehicleType getType() {
		return bikeType;
	}

}

package hr.vestigo.java.education.hw5.parking.vehicle;

/**
 * This interface represents vehicle.
 * 
 * @author ivona
 *
 */
public interface Vehicle {
	/**
	 * Getter of size of vehicle.
	 * 
	 * @return size of vehicle
	 */
	VehicleSize getSize();

	/**
	 * Getter of type of vehicle.
	 * 
	 * @return type of vehicle
	 */
	VehicleType getType();
}

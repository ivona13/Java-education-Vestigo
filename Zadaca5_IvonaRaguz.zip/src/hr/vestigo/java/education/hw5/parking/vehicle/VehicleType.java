package hr.vestigo.java.education.hw5.parking.vehicle;

/**
 * This class represents possible different types of vehicles.
 * 
 * @author ivona
 *
 */
public enum VehicleType {
	/**
	 * Regular type of vehicle
	 */
	REGULAR,

	/**
	 * Type of vehicle intended for disabled people
	 */
	HANDICAPPED
}

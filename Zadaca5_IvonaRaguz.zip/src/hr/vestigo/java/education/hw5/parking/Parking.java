package hr.vestigo.java.education.hw5.parking;

import hr.vestigo.java.education.hw5.parking.parkinglot.ParkingLot;
import hr.vestigo.java.education.hw5.parking.vehicle.Bike;
import hr.vestigo.java.education.hw5.parking.vehicle.Car;
import hr.vestigo.java.education.hw5.parking.vehicle.Truck;
import hr.vestigo.java.education.hw5.parking.vehicle.VehicleType;

/**
 * This class is used to demonstrate parking of different types of vehicles on
 * parking plot.
 * 
 * @author ivona
 *
 */
public class Parking {

	/**
	 * This method is executed after running the program.
	 * 
	 * @param args Command arguments
	 */
	public static void main(String[] args) {
		ParkingLot parkingLot = new ParkingLot(10, 24, 9, 0, 5, 0);

		System.out.println("Parking Medium Handicapped cars:");
		parkingLot.park(new Car(VehicleType.HANDICAPPED));
		parkingLot.park(new Car(VehicleType.HANDICAPPED));
		parkingLot.park(new Car(VehicleType.HANDICAPPED));
		parkingLot.park(new Car(VehicleType.HANDICAPPED));
		parkingLot.park(new Car(VehicleType.HANDICAPPED));
		parkingLot.park(new Car(VehicleType.HANDICAPPED));
		System.out.println();

		System.out.println("Parking Large regular trucks:");
		parkingLot.park(new Truck(VehicleType.REGULAR));
		parkingLot.park(new Truck(VehicleType.REGULAR));
		parkingLot.park(new Truck(VehicleType.REGULAR));
		parkingLot.park(new Truck(VehicleType.REGULAR));
		parkingLot.park(new Truck(VehicleType.REGULAR));
		parkingLot.park(new Truck(VehicleType.REGULAR));
		parkingLot.park(new Truck(VehicleType.REGULAR));
		parkingLot.park(new Truck(VehicleType.REGULAR));
		System.out.println();

		System.out.println("Parking Medium Regular cars:");
		parkingLot.park(new Car(VehicleType.REGULAR));
		parkingLot.park(new Car(VehicleType.REGULAR));
		parkingLot.park(new Car(VehicleType.REGULAR));
		System.out.println();

		System.out.println("Parking Large Handicapped truck:");
		parkingLot.park(new Truck(VehicleType.REGULAR));
		System.out.println();

		System.out.println("Parking Large Regular truck:");
		parkingLot.park(new Truck(VehicleType.REGULAR));
		System.out.println();

		System.out.println("Parking Large Handicapped truck:");
		parkingLot.park(new Truck(VehicleType.HANDICAPPED));
		System.out.println();

		System.out.println("Parking Small Regular bike:");
		parkingLot.park(new Bike(VehicleType.REGULAR));
		parkingLot.park(new Bike(VehicleType.REGULAR));
		parkingLot.park(new Bike(VehicleType.REGULAR));
		System.out.println();

		System.out.println("Parking Medium Regular car:");
		parkingLot.park(new Car(VehicleType.REGULAR));
		System.out.println();

		System.out.println("Is the parking lot full? " + parkingLot.isParkingLotFull() + "\n");

		System.out.println("What spots are left?\n");
		parkingLot.showFreeSpots();
	}
}

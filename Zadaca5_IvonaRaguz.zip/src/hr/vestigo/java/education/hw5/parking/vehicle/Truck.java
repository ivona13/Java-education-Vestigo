package hr.vestigo.java.education.hw5.parking.vehicle;

/**
 * This class is used to represent truck.
 * 
 * @author ivona
 *
 */
public class Truck implements Vehicle {

	/**
	 * Type of truck - regular or handicapped
	 */
	VehicleType truckType;

	/**
	 * Constructor
	 * 
	 * @param truckType type of truck
	 */
	public Truck(VehicleType truckType) {
		this.truckType = truckType;
	}

	@Override
	public VehicleSize getSize() {
		return VehicleSize.LARGE;
	}

	@Override
	public VehicleType getType() {
		return truckType;
	}

}

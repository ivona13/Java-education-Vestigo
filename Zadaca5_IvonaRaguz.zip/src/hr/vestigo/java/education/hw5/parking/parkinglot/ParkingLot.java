package hr.vestigo.java.education.hw5.parking.parkinglot;

import hr.vestigo.java.education.hw5.parking.vehicle.Vehicle;
import hr.vestigo.java.education.hw5.parking.vehicle.VehicleSize;
import hr.vestigo.java.education.hw5.parking.vehicle.VehicleType;

/**
 * This class is used to represent parking lot. <br/>
 * Different vehicles are trying to be parked on appropriate spot on the parking
 * plot.
 * 
 * @author ivona
 *
 */
public class ParkingLot {

	/**
	 * Spots for large regular vehicles
	 */
	int largeRegularSpots;
	/**
	 * Spots for medium regular vehicles
	 */
	int mediumRegularSpots;
	/**
	 * Spots for small regular vehicles
	 */
	int smallRegularSpots;
	/**
	 * Spots for large vehicles for disabled people
	 */
	int largeHandicappedSpots;
	/**
	 * Spots for medium vehicles for disabled people
	 */
	int mediumHandicappedSpots;
	/**
	 * Spots for small vehicles for disabled people
	 */
	int smallHandicappedSpots;

	/**
	 * Initializing parking lot.
	 * 
	 * @param largeRegularSpots      number of large regular spots
	 * @param mediumRegularSpots     number of medium regular spots
	 * @param smallRegularSpots      number of small regular spots
	 * @param largeHandicappedSpots  number of large handicapped spots
	 * @param mediumHandicappedSpots number of medium handicapped spots
	 * @param smallHandicappedSpots  number of small handicapped spots
	 */
	public ParkingLot(int largeRegularSpots, int mediumRegularSpots, int smallRegularSpots, int largeHandicappedSpots,
			int mediumHandicappedSpots, int smallHandicappedSpots) {
		this.largeRegularSpots = largeRegularSpots;
		this.mediumRegularSpots = mediumRegularSpots;
		this.smallRegularSpots = smallRegularSpots;
		this.largeHandicappedSpots = largeHandicappedSpots;
		this.mediumHandicappedSpots = mediumHandicappedSpots;
		this.smallHandicappedSpots = smallHandicappedSpots;
	}

	/**
	 * This method is used for trying to park a vehicle to appropriate spot. <br/>
	 * Vehicles of regular type can be parked only on spots of regular type. <br/>
	 * Vehicles for disabled can take place on spots of both types - regular and
	 * handicapped.<br/>
	 * Small vehicles can be parked on small, medium and large spots. <br/>
	 * Medium vehicles can be parked on medium and large spots.<br/>
	 * Large vehicles can be parked on large spots.<br/>
	 * 
	 * 
	 * @param vehicle
	 */
	public void park(Vehicle vehicle) {
		VehicleSize vehicleSize = vehicle.getSize();
		VehicleType vehicleType = vehicle.getType();

		switch (vehicleSize) {
		case SMALL:
			if (vehicleType == VehicleType.HANDICAPPED && smallHandicappedSpots > 0) {
				smallHandicappedSpots--;
				System.out.println("The car has parked in a SMALL HANDICAPPED.");
				return;
			}
			if (smallRegularSpots > 0) {
				smallRegularSpots--;
				System.out.println("The car has parked in a SMALL REGULAR.");
				return;
			}
			// drop to the next case
		case MEDIUM:
			if (vehicleType == VehicleType.HANDICAPPED && mediumHandicappedSpots > 0) {
				mediumHandicappedSpots--;
				System.out.println("The car has parked in a MEDIUM HANDICAPPED.");
				return;
			}
			if (mediumRegularSpots > 0) {
				mediumRegularSpots--;
				System.out.println("The car has parked in a MEDIUM REGULAR.");
				return;
			}

		case LARGE:
			if (vehicleType == VehicleType.HANDICAPPED && largeHandicappedSpots > 0) {
				largeHandicappedSpots--;
				System.out.println("The car has parked in a LARGE HANDICAPPED.");
				return;
			}
			if (largeRegularSpots > 0) {
				largeRegularSpots--;
				System.out.println("The car has parked in a LARGE REGULAR.");
				return;
			}

		default:
			// no place anywhere
			System.out.println("The car cannot be parked at this time.");
			break;
		}
	}

	/**
	 * This method is used for showing free spots of every type on the parking lot.
	 */
	public void showFreeSpots() {
		System.out.println("There are " + smallRegularSpots + " SMALL REGULAR spots left.");
		System.out.println("There are " + smallHandicappedSpots + " SMALL HANDICAPPED spots left.");
		System.out.println("There are " + mediumRegularSpots + " MEDIUM REGULAR spots left.");
		System.out.println("There are " + mediumHandicappedSpots + " MEDIUM HANDICAPPED spots left.");
		System.out.println("There are " + largeRegularSpots + " LARGE REGULAR spots left.");
		System.out.println("There are " + largeHandicappedSpots + " LARGE HANDICAPPED spots left.");
	}

	/**
	 * This method is used for checking if the parking lot is without any free spot.
	 * 
	 * @return true if the parking lot is full <br/>
	 *         false otherwise
	 */
	public boolean isParkingLotFull() {
		return !(largeRegularSpots > 0 || mediumRegularSpots > 0 || smallRegularSpots > 0 || largeHandicappedSpots > 0
				|| largeHandicappedSpots > 0 || smallHandicappedSpots > 0);
	}
}

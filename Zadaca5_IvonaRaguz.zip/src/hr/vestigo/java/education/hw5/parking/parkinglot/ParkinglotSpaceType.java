package hr.vestigo.java.education.hw5.parking.parkinglot;

/**
 * Types of spaces of parking lot.
 * 
 * @author ivona
 *
 */
public enum ParkinglotSpaceType {
	/**
	 * Space for regular large vehicles
	 */
	REGULAR_LARGE,

	/**
	 * Space for large vehicles for disabled people
	 */
	HANDICAPPED_LARGE,

	/**
	 * Space for regular medium vehicles
	 */
	REGULAR_MEDIUM,

	/**
	 * Space for medium vehicles for disabled people
	 */
	HANDICAPPED_MEDIUM,

	/**
	 * Space for regular small vehicles
	 */
	REGULAR_SMALL,

	/**
	 * Space for small vehicles for disabled people
	 */
	HANDICAPPED_SMALL
}

package hr.vestigo.java.education.hw5.parking.vehicle;

/**
 * This class is used to represent car.
 * 
 * @author ivona
 *
 */
public class Car implements Vehicle {

	/**
	 * Type of car - regular or handicapped
	 */
	VehicleType carType;

	/**
	 * Constructor
	 * 
	 * @param carType type of car
	 */
	public Car(VehicleType carType) {
		this.carType = carType;
	}

	@Override
	public VehicleSize getSize() {
		return VehicleSize.MEDIUM;
	}

	@Override
	public VehicleType getType() {
		return carType;
	}

}

package hr.vestigo.java.education.hw3.football;

/**
 * This class is used to represent football match between two teams.
 * 
 * @author ivona
 */
public class FootballMatch {

	/**
	 * Number of players per team
	 */
	@SuppressWarnings("unused")
	private static int NUMBER_OF_PLAYERS_PER_TEAM = 11;

	/**
	 * This method is used to check the winner of the match. <br/>
	 * Winner is declared with a note about the team who did more faults.
	 * 
	 * @param team1 first team
	 * @param team2 second team
	 */
	public static void checkTheWinner(Team team1, Team team2) {
		if (!team1.checkStatistics() || !team2.checkStatistics()) {
			System.out.println("Statistics not valid.");
			return;
		}

		Team winner, loser;

		if (team2.numberOfScoredGoals() == team1.numberOfScoredGoals()) {
			System.out.println("This match has no winner.");
			return;
		}

		winner = (team1.numberOfScoredGoals() < team2.numberOfScoredGoals()) ? team2 : team1;
		loser = (team1.numberOfScoredGoals() < team2.numberOfScoredGoals()) ? team1 : team2;

		System.out.println("The winner is " + winner.toString() + ".");

		boolean equalFoul = winner.numberOfFaults() == loser.numberOfFaults();
		if (equalFoul) {
			System.out.println("Both teams did equal number of fouls.");
		} else {
			String foulNote = (winner.numberOfFaults() < loser.numberOfFaults()) ? "less" : "more";
			System.out.println("The winner did " + foulNote + " fouls than the other team.");
		}

		System.out.println("Number of scored goals of winner: " + winner.numberOfScoredGoals());
		System.out.println("Number of fouls of winner: " + winner.numberOfFaults());
	}

	/**
	 * This method is executed after running the program.
	 * 
	 * @param args command arguments
	 */
	public static void main(String[] args) {
		Team blue = new Team("Blue", 55, 77);
		Team white = new Team("White", 56, 89);

		checkTheWinner(blue, white);
	}

}

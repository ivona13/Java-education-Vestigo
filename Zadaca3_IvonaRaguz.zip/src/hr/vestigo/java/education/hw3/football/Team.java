package hr.vestigo.java.education.hw3.football;

/**
 * This class is used to represent football team. <br/>
 * Football team has its dress color, offense statistics and defensive
 * statistics.<br/>
 * 
 * @author ivona
 *
 */
public class Team {

	/**
	 * lower bound for valid statistics
	 */
	private final int LOWER_STATS_BOUND = 1;
	/**
	 * upper bound for valid statistics
	 */
	private final int UPPER_STATS_BOUND = 100;

	/**
	 * dress color of team
	 */
	private String dressColor;
	/**
	 * defense statistics
	 */
	private int defenseStats;
	/**
	 * attack statistics
	 */
	private int attackStats;

	/**
	 * Constructor
	 * 
	 * @param dressColor   dress color
	 * @param offenseStats offense statistics
	 * @param defenseStats defense statistics
	 */
	public Team(String dressColor, int defenseStats, int attackStats) {
		this.dressColor = dressColor;
		this.defenseStats = defenseStats;
		this.attackStats = attackStats;
	}

	/**
	 * Dress color getter
	 * 
	 * @return dress color
	 */
	public String getDressColor() {
		return dressColor;
	}

	/**
	 * Defense statistics getter
	 * 
	 * @return defense statistics
	 */
	public int getDefenseStats() {
		return defenseStats;
	}

	/**
	 * Attack statistics getter
	 * 
	 * @return attack statistics
	 */
	public int getAttackStats() {
		return attackStats;
	}

	/**
	 * This method is used to check if team statistics are in allowed range. <br/>
	 * Stats are valid if they are in a range of 1 to 100. <br/>
	 * 
	 * @return true if stats are in allowed range<br/>
	 *         false otherwise
	 */
	public boolean checkStatistics() {
		boolean attackValid = attackStats >= LOWER_STATS_BOUND && attackStats <= UPPER_STATS_BOUND;
		boolean defensiveValid = defenseStats >= LOWER_STATS_BOUND && defenseStats <= UPPER_STATS_BOUND;
		if (!attackValid) {
			System.out.println("Attack stats is not valid.");
		}
		if (!defensiveValid) {
			System.out.println("Defense stats is not valid.");
		}
		return attackValid && defensiveValid;
	}

	/**
	 * This method is used to give number of scored goals of the team.
	 * 
	 * @return number of scored goals
	 */
	public int numberOfScoredGoals() {
		return attackStats / 10;
	}

	/**
	 * This method is used to give number of faults of the team.
	 * 
	 * @return number of faults
	 */
	public int numberOfFaults() {
		return (100 - defenseStats) / 10;
	}
	
	@Override
	public String toString() {
		return dressColor + " team";
	}
}

package hr.vestigo.java.education.hw3.numbers;

/**
 * This class is used to demonstrate categorization of one digit, two digit and
 * three digit numbers.<br/>
 * First category contains one digit and two digit prime numbers.<br/>
 * Second category contains three digit palindrome numbers.
 * 
 * @author ivona
 *
 */
public class CategorizeNumberTask {

	/**
	 * The smallest positive number
	 */
	private static final int LOWER_BOUND = 1;
	/**
	 * The largest three digit number
	 */
	private static final int UPPER_BOUND = 999;

	/**
	 * This method is used to determine if a number is prime. <br/>
	 * 
	 * @param number number to check its primality
	 * @return true if number is prime <br/>
	 *         false otherwise
	 */
	private static boolean isPrime(int number) {
		if (number < 2) {
			return false;
		}
		for (int i = 2; i <= Math.sqrt(number); i++) {
			if (number % i == 0) {
				return false;
			}
		}
		return true;
	}

	/**
	 * This method is used to check if string is palindrome.
	 * 
	 * @param string string to check if it is palindrome
	 * @return true if string is palindrome <br/>
	 *         false otherwise
	 */
	private static boolean isPalindrome(String string) {
		int length = string.length();
		for (int i = 0; i < length / 2; i++) {
			if (string.charAt(i) != string.charAt(length - 1 - i)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * This method is used to check if input number has specific number of digits.
	 * 
	 * @param n      number of digits to check if input number has
	 * @param number number to check
	 * @return true if number has n digits <br/>
	 *         false otherwise
	 */
	public static boolean hasNDigits(int n, int number) {
		if (n < 1) {
			System.out.println("Number of digits is less than one.");
			return false;
		}
		return String.valueOf(number).length() == n;
	}

	/**
	 * This method is executed after running the program.
	 * 
	 * @param args command arguments
	 */
	public static void main(String[] args) {

		for (int number = LOWER_BOUND; number <= UPPER_BOUND; number++) {
			boolean firstCategory = (hasNDigits(1, number) || hasNDigits(2, number)) && isPrime(number);
			boolean secondCategory = hasNDigits(3, number) && isPalindrome(String.valueOf(number));

			if (firstCategory || secondCategory) {
				System.out.println(number);
			}
		}
	}
}
